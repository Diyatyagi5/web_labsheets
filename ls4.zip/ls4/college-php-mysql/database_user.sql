-- Run as a MySQL administrator after database_setup.sql and create_students_table.php.
-- Replace the example password before executing this file.
CREATE USER IF NOT EXISTS 'college_app'@'localhost'
    IDENTIFIED BY 'Replace-With-A-Long-Random-Password';

-- The web account is limited to the requested read/insert/update operations.
GRANT SELECT, INSERT, UPDATE ON college_db.* TO 'college_app'@'localhost';
