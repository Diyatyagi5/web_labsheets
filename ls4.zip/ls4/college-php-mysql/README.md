# College PHP and MySQL lab

This folder contains the exercises as individual PHP files, SQL scripts, and local server configuration examples. It does not configure software outside this project folder.

## Local setup

1. Install or use a local Apache + PHP bundle such as XAMPP, or use your existing Apache and PHP installation. Start Apache and MySQL. The workspace check found a running Windows service named MySQL80, but PHP and Apache commands were not available on PATH.
2. Make a copy of config.local.php.example named config.local.php. Set the database host, name, username, and password for your local MySQL installation. The application account password must match the password set in database_user.sql. This file is excluded from Git.
3. Merge the directives from php.ini.example into the active php.ini. Find the active file by opening phpinfo.php and reading “Loaded Configuration File”. Restart Apache after changes.
4. Open database_setup.sql in a MySQL client as an administrator, or run mysql -u root -p < database_setup.sql. This creates college_db, the authentication table, and the transaction tables.
5. Temporarily configure config.local.php with a database administrator account, then run create_students_table.php once. Change config.local.php to the dedicated application account afterward. Remove or protect the setup page after it runs.
6. Run database_user.sql as a MySQL administrator after the tables are created. Replace its example password first. It grants the application account only SELECT, INSERT, and UPDATE on college_db.
7. To enable the specific delete exercise, also run database_user_delete_optional.sql. This adds only the DELETE privilege on the students table.

If the project is inside Apache's document root, open http://localhost/college-php-mysql/. If Apache's document root points directly at this folder, open http://localhost/.

## Virtual host

1. Copy the VirtualHost block from httpd-vhosts.conf into Apache's conf/extra/httpd-vhosts.conf. Replace both example paths with the absolute path to this folder, using forward slashes.
2. Ensure the main Apache httpd.conf includes conf/extra/httpd-vhosts.conf, then restart Apache. The localhost block serves this project's index.php at http://localhost/.
3. Add 127.0.0.1 collegeweb.local to the Windows hosts file at C:\Windows\System32\drivers\etc\hosts using an administrator editor.
4. Open http://collegeweb.local/. The VirtualHost writes separate collegeweb-access.log and collegeweb-error.log files under Apache's logs directory.

## Exercise files

| Exercise | File or setup artifact |
| --- | --- |
| Default PHP test page and localhost landing page | index.php |
| PHP error display and diagnostics | php.ini.example, phpinfo.php |
| Create database | database_setup.sql |
| PDO connection and status | config.php, db.php, connection_status.php |
| Create students table using PHP SQL | create_students_table.php |
| Insert student with prepared statement | add_student.php |
| Display student records in a styled table | students.php |
| Update a student's email by ID | update_student.php |
| Delete using a GET ID and a CSRF-protected confirmation form | delete_student.php |
| Apache virtual host | httpd-vhosts.conf |
| Inspect $_SERVER information | server_info.php |
| Database-backed authentication | register.php, login.php, dashboard.php, logout.php |
| Validate and store image uploads | upload.php, uploads/.htaccess |
| Restricted database account | database_user.sql, database_user_delete_optional.sql |
| PHP session state | login.php, dashboard.php, session_demo.php |
| Theme preference cookie | theme_cookie.php |
| Download student CSV | export_students.php |
| Apache and PHP log/performance check | VirtualHost log settings and steps below |
| PDO transaction with commit and rollback | transaction_demo.php, database_setup.sql |
| PHP extensions | php.ini.example, phpinfo.php |
| password_hash() and password_verify() | register.php, login.php |

## Run and verify

1. Open phpinfo.php, confirm the active configuration path, display_errors, and these modules: mysqli, pdo_mysql, mbstring, curl, and fileinfo. Keep display_errors = On only for local development.
2. Open connection_status.php; it should report a successful PDO connection. Then open create_students_table.php once with the temporary setup account.
3. Create an account with register.php, sign in with login.php, and confirm dashboard.php shows the login session. session_demo.php counts visits in the same browser session.
4. Add records with add_student.php, view them with students.php, update an email with update_student.php, and export with export_students.php. To delete, open delete_student.php?id=1 and confirm the form.
5. Upload a small image with upload.php, save a theme with theme_cookie.php, and try a transfer between account IDs 1 and 2 with transaction_demo.php.
6. Open server_info.php to display selected Apache values from $_SERVER.
7. For a simple local response-time sample in PowerShell, run Measure-Command { 1..20 | ForEach-Object { Invoke-WebRequest -UseBasicParsing http://localhost/connection_status.php | Out-Null } }. This is a small sequential check, not a load benchmark.
8. Generate an access-log entry by requesting http://localhost/connection_status.php. Generate a 404 entry by requesting a nonexistent path, then inspect Apache's configured access and error logs. With XAMPP, the default log directory is commonly C:\xampp\apache\logs; use the actual paths from your Apache configuration.

No local Apache/PHP request or MySQL PDO connection could be verified from this workspace because Apache and PHP were unavailable in the environment. MySQL service status alone does not confirm that the database, credentials, or PDO connection are working.
