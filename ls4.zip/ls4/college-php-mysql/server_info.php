<?php
declare(strict_types=1);
require __DIR__ . '/common.php';
$keys = [
    'SERVER_SOFTWARE',
    'SERVER_NAME',
    'SERVER_ADDR',
    'SERVER_PORT',
    'DOCUMENT_ROOT',
    'REQUEST_METHOD',
    'REQUEST_URI',
    'REMOTE_ADDR',
    'HTTPS',
];
page_start('Apache Server Environment');
?>
<p>PHP version: <?= h(PHP_VERSION) ?></p>
<table>
    <thead><tr><th>Server variable</th><th>Value</th></tr></thead>
    <tbody>
    <?php foreach ($keys as $key): ?>
        <tr><td><?= h($key) ?></td><td><?= h($_SERVER[$key] ?? '(not set)') ?></td></tr>
    <?php endforeach; ?>
    </tbody>
</table>
<?php page_end(); ?>
