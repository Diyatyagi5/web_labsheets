<?php
declare(strict_types=1);
require __DIR__ . '/common.php';
$pdo = require __DIR__ . '/db.php';
$message = '';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    if (!valid_csrf_token()) {
        http_response_code(400);
        $message = 'Invalid form token. Reload the page and try again.';
    } else {
        $username = trim((string) ($_POST['username'] ?? ''));
        $password = (string) ($_POST['password'] ?? '');
        if (!preg_match('/\A[a-zA-Z0-9_.-]{3,80}\z/', $username) || strlen($password) < 12) {
            $message = 'Use a 3–80 character username and a password of at least 12 characters.';
        } else {
            try {
                $statement = $pdo->prepare(
                    'INSERT INTO auth_users (username, password_hash) VALUES (:username, :password_hash)'
                );
                $statement->execute([
                    'username' => $username,
                    'password_hash' => password_hash($password, PASSWORD_DEFAULT),
                ]);
                $message = 'Account created. You can now sign in.';
            } catch (PDOException $exception) {
                if ($exception->getCode() === '23000') {
                    $message = 'That username is already in use.';
                } else {
                    throw $exception;
                }
            }
        }
    }
}

page_start('Create Demo Account');
echo '<p class="muted">Open registration is for this local exercise only. Restrict account creation on a real site.</p>';
if ($message !== '') {
    echo '<p>' . h($message) . '</p>';
}
?>
<form method="post">
    <input type="hidden" name="csrf_token" value="<?= h(csrf_token()) ?>">
    <label>Username <input name="username" minlength="3" maxlength="80" required></label>
    <label>Password <input type="password" name="password" minlength="12" required></label>
    <button type="submit">Create account</button>
</form>
<?php page_end(); ?>
