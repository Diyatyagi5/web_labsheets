<?php
declare(strict_types=1);
require __DIR__ . '/common.php';
$pdo = require __DIR__ . '/db.php';
$pdo->query('SELECT 1');
page_start('PDO Connection Status');
?>
<p class="ok">Connected successfully to the MySQL database using PDO.</p>
<p>Database: <?= h($pdo->query('SELECT DATABASE()')->fetchColumn()) ?></p>
<?php page_end(); ?>
