<?php
declare(strict_types=1);
require __DIR__ . '/common.php';
$pdo = require __DIR__ . '/db.php';
$message = '';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    if (!valid_csrf_token()) {
        http_response_code(400);
        $message = 'Invalid form token. Reload the page and try again.';
    } else {
        $fromId = filter_input(INPUT_POST, 'from_id', FILTER_VALIDATE_INT);
        $toId = filter_input(INPUT_POST, 'to_id', FILTER_VALIDATE_INT);
        $amountText = trim((string) ($_POST['amount'] ?? ''));
        if (
            !$fromId || !$toId || $fromId === $toId
            || !preg_match('/\A\d{1,10}(?:\.\d{1,2})?\z/', $amountText)
            || (float) $amountText <= 0
        ) {
            $message = 'Enter two different account IDs and an amount greater than zero.';
        } else {
            $amount = number_format((float) $amountText, 2, '.', '');
            try {
                $pdo->beginTransaction();
                $lock = $pdo->prepare(
                    'SELECT id, balance FROM accounts WHERE id IN (?, ?) ORDER BY id FOR UPDATE'
                );
                $lock->execute([$fromId, $toId]);
                $accounts = [];
                foreach ($lock->fetchAll() as $account) {
                    $accounts[(int) $account['id']] = $account;
                }
                if (!isset($accounts[$fromId], $accounts[$toId])) {
                    throw new RuntimeException('Both accounts must exist.');
                }
                if ((float) $accounts[$fromId]['balance'] < (float) $amount) {
                    throw new RuntimeException('The source account has insufficient funds.');
                }

                $debit = $pdo->prepare(
                    'UPDATE accounts SET balance = balance - :amount WHERE id = :id AND balance >= :minimum'
                );
                $debit->execute(['amount' => $amount, 'id' => $fromId, 'minimum' => $amount]);
                $credit = $pdo->prepare('UPDATE accounts SET balance = balance + :amount WHERE id = :id');
                $credit->execute(['amount' => $amount, 'id' => $toId]);
                $record = $pdo->prepare(
                    'INSERT INTO account_transfers (from_account_id, to_account_id, amount) VALUES (?, ?, ?)'
                );
                $record->execute([$fromId, $toId, $amount]);
                $pdo->commit();
                $message = 'Transfer committed successfully.';
            } catch (RuntimeException $exception) {
                if ($pdo->inTransaction()) {
                    $pdo->rollBack();
                }
                $message = 'Transfer failed and was rolled back: ' . $exception->getMessage();
            } catch (Throwable $exception) {
                if ($pdo->inTransaction()) {
                    $pdo->rollBack();
                }
                error_log('Transfer rolled back: ' . $exception->getMessage());
                $message = 'Transfer failed and was rolled back. Check the PHP error log.';
            }
        }
    }
}

$accounts = $pdo->query('SELECT id, account_name, balance FROM accounts ORDER BY id')->fetchAll();
page_start('PDO Transaction Demo');
if ($message !== '') {
    echo '<p>' . h($message) . '</p>';
}
?>
<table>
    <thead><tr><th>ID</th><th>Account</th><th>Balance</th></tr></thead>
    <tbody>
    <?php foreach ($accounts as $account): ?>
        <tr><td><?= h($account['id']) ?></td><td><?= h($account['account_name']) ?></td><td><?= h($account['balance']) ?></td></tr>
    <?php endforeach; ?>
    </tbody>
</table>
<form method="post">
    <input type="hidden" name="csrf_token" value="<?= h(csrf_token()) ?>">
    <label>From account ID <input type="number" name="from_id" min="1" value="1" required></label>
    <label>To account ID <input type="number" name="to_id" min="1" value="2" required></label>
    <label>Amount <input type="number" name="amount" min="0.01" step="0.01" required></label>
    <button type="submit">Transfer</button>
</form>
<?php page_end(); ?>
