<?php
declare(strict_types=1);
require __DIR__ . '/common.php';
$pdo = require __DIR__ . '/db.php';
start_app_session();
$id = filter_input(INPUT_GET, 'id', FILTER_VALIDATE_INT);
$message = '';

if (!$id || $id < 1) {
    http_response_code(400);
    $message = 'Provide a valid student ID in the URL, for example ?id=1.';
} elseif ($_SERVER['REQUEST_METHOD'] === 'POST') {
    if (!valid_csrf_token()) {
        http_response_code(400);
        $message = 'Invalid form token. Reload the page and try again.';
    } else {
        $statement = $pdo->prepare('DELETE FROM students WHERE id = :id');
        $statement->execute(['id' => $id]);
        $message = $statement->rowCount() > 0 ? 'Student deleted.' : 'No matching student was found.';
    }
}

page_start('Delete Student');
if ($message !== '') {
    echo '<p>' . h($message) . '</p>';
}
if ($id && $id > 0 && $_SERVER['REQUEST_METHOD'] === 'GET') {
    $statement = $pdo->prepare('SELECT id, name, email FROM students WHERE id = :id');
    $statement->execute(['id' => $id]);
    $student = $statement->fetch();
    if ($student) {
        ?>
        <p>Confirm deletion of student <?= h($student['name']) ?> (<?= h($student['email']) ?>), ID <?= h($id) ?>.</p>
        <form method="post" action="?id=<?= h($id) ?>">
            <input type="hidden" name="csrf_token" value="<?= h(csrf_token()) ?>">
            <button type="submit">Confirm delete</button>
        </form>
        <?php
    } else {
        echo '<p>No matching student was found.</p>';
    }
}
page_end();
