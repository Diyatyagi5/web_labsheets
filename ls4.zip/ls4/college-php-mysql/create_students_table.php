<?php
declare(strict_types=1);

// Run once with a database account that has CREATE permission, then remove/protect this page.
$pdo = require __DIR__ . '/db.php';
$pdo->exec(
    'CREATE TABLE IF NOT EXISTS students (
        id INT UNSIGNED NOT NULL AUTO_INCREMENT PRIMARY KEY,
        name VARCHAR(120) NOT NULL,
        email VARCHAR(254) NOT NULL UNIQUE,
        enrollment_date DATE NOT NULL
    ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci'
);
header('Content-Type: text/plain; charset=utf-8');
echo 'The students table is ready.';
