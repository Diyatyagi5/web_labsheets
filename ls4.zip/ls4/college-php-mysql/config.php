<?php
declare(strict_types=1);

$localConfig = [];
$localConfigFile = __DIR__ . '/config.local.php';
if (is_file($localConfigFile)) {
    $localConfig = require $localConfigFile;
}

return [
    'db_host' => getenv('COLLEGE_DB_HOST') ?: ($localConfig['db_host'] ?? '127.0.0.1'),
    'db_name' => getenv('COLLEGE_DB_NAME') ?: ($localConfig['db_name'] ?? 'college_db'),
    'db_user' => getenv('COLLEGE_DB_USER') ?: ($localConfig['db_user'] ?? 'college_app'),
    'db_pass' => getenv('COLLEGE_DB_PASS') !== false
        ? (string) getenv('COLLEGE_DB_PASS')
        : (string) ($localConfig['db_pass'] ?? ''),
];
