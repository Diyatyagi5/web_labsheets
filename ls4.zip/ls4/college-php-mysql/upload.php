<?php
declare(strict_types=1);
require __DIR__ . '/common.php';
$message = '';
$allowedMimeTypes = [
    'image/jpeg' => 'jpg',
    'image/png' => 'png',
    'image/gif' => 'gif',
    'image/webp' => 'webp',
];
$maxBytes = 3 * 1024 * 1024;

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    if (!valid_csrf_token()) {
        http_response_code(400);
        $message = 'Invalid form token. Reload the page and try again.';
    } elseif (!isset($_FILES['image']) || !is_array($_FILES['image'])) {
        $message = 'Choose an image to upload.';
    } else {
        $file = $_FILES['image'];
        if ($file['error'] !== UPLOAD_ERR_OK) {
            $message = 'Upload failed with code ' . (int) $file['error'] . '.';
        } elseif ($file['size'] < 1 || $file['size'] > $maxBytes) {
            $message = 'The image must be smaller than 3 MB.';
        } else {
            $finfo = new finfo(FILEINFO_MIME_TYPE);
            $mime = $finfo->file($file['tmp_name']);
            $imageInfo = @getimagesize($file['tmp_name']);
            if (!isset($allowedMimeTypes[$mime]) || $imageInfo === false) {
                $message = 'Only valid JPG, PNG, GIF, and WebP images are accepted.';
            } else {
                $uploadDir = __DIR__ . '/uploads';
                if (!is_dir($uploadDir) && !mkdir($uploadDir, 0750, true) && !is_dir($uploadDir)) {
                    throw new RuntimeException('Could not create upload directory.');
                }
                $filename = bin2hex(random_bytes(16)) . '.' . $allowedMimeTypes[$mime];
                if (move_uploaded_file($file['tmp_name'], $uploadDir . '/' . $filename)) {
                    $message = 'Image saved as uploads/' . $filename . '.';
                } else {
                    $message = 'The server could not save the uploaded image.';
                }
            }
        }
    }
}

page_start('Image Upload');
if ($message !== '') {
    echo '<p>' . h($message) . '</p>';
}
?>
<p>Allowed: JPG, PNG, GIF, or WebP. Maximum file size: 3 MB.</p>
<form method="post" enctype="multipart/form-data">
    <input type="hidden" name="csrf_token" value="<?= h(csrf_token()) ?>">
    <label>Image <input type="file" name="image" accept="image/jpeg,image/png,image/gif,image/webp" required></label>
    <button type="submit">Upload image</button>
</form>
<?php page_end(); ?>
