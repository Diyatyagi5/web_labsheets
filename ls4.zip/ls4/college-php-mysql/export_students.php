<?php
declare(strict_types=1);
$pdo = require __DIR__ . '/db.php';
$statement = $pdo->query('SELECT id, name, email, enrollment_date FROM students ORDER BY id');

header('Content-Type: text/csv; charset=utf-8');
header('Content-Disposition: attachment; filename="students.csv"');
header('X-Content-Type-Options: nosniff');
$output = fopen('php://output', 'wb');
fputcsv($output, ['id', 'name', 'email', 'enrollment_date'], ',', '"', '\\');
while ($student = $statement->fetch(PDO::FETCH_NUM)) {
    $safeStudent = array_map(static function ($value): string {
        $cell = (string) $value;
        if (preg_match('/\A[\t\r ]*[=+\-@]/', $cell)) {
            $cell = "'" . $cell;
        }
        return $cell;
    }, $student);
    fputcsv($output, $safeStudent, ',', '"', '\\');
}
fclose($output);
