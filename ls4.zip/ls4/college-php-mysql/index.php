<?php
declare(strict_types=1);
require __DIR__ . '/common.php';
page_start('College PHP and MySQL Lab');
?>
<p>This local project contains separate PHP examples for Apache, PHP, PDO, MySQL, authentication, uploads, sessions, cookies, CSV export, and transactions.</p>
<p>Start with the README.md file, create config.local.php from config.local.php.example, and open each exercise by its filename after Apache is configured.</p>
<p class="muted">For example, use the connection status, table setup, student CRUD, login, file upload, CSV export, server information, and transaction exercises individually.</p>
<?php page_end(); ?>
