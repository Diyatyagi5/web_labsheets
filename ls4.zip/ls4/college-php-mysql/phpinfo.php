<?php
// Development-only diagnostic. Remove or protect this page on a public server.
phpinfo();
