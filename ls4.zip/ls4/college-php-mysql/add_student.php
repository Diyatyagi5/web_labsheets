<?php
declare(strict_types=1);
require __DIR__ . '/common.php';
$pdo = require __DIR__ . '/db.php';
$message = '';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    if (!valid_csrf_token()) {
        http_response_code(400);
        $message = 'Invalid form token. Reload the page and try again.';
    } else {
        $name = trim((string) ($_POST['name'] ?? ''));
        $email = trim((string) ($_POST['email'] ?? ''));
        $date = (string) ($_POST['enrollment_date'] ?? date('Y-m-d'));
        $dateValue = DateTimeImmutable::createFromFormat('!Y-m-d', $date);
        if (
            $name === ''
            || !filter_var($email, FILTER_VALIDATE_EMAIL)
            || $dateValue === false
            || $dateValue->format('Y-m-d') !== $date
        ) {
            $message = 'Enter a name, valid email address, and valid enrollment date.';
        } else {
            $statement = $pdo->prepare(
                'INSERT INTO students (name, email, enrollment_date) VALUES (:name, :email, :enrollment_date)'
            );
            $statement->execute([
                'name' => $name,
                'email' => $email,
                'enrollment_date' => $date,
            ]);
            $message = 'Student added. New student ID: ' . $pdo->lastInsertId();
        }
    }
}

page_start('Add Student');
if ($message !== '') {
    echo '<p>' . h($message) . '</p>';
}
?>
<form method="post">
    <input type="hidden" name="csrf_token" value="<?= h(csrf_token()) ?>">
    <label>Name <input name="name" maxlength="120" required></label>
    <label>Email <input type="email" name="email" maxlength="254" required></label>
    <label>Enrollment date <input type="date" name="enrollment_date" value="<?= h(date('Y-m-d')) ?>" required></label>
    <button type="submit">Add student</button>
</form>
<?php page_end(); ?>
