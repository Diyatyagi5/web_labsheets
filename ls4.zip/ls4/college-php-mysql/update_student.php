<?php
declare(strict_types=1);
require __DIR__ . '/common.php';
$pdo = require __DIR__ . '/db.php';
$message = '';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    if (!valid_csrf_token()) {
        http_response_code(400);
        $message = 'Invalid form token. Reload the page and try again.';
    } else {
        $id = filter_input(INPUT_POST, 'id', FILTER_VALIDATE_INT);
        $email = trim((string) ($_POST['email'] ?? ''));
        if (!$id || !filter_var($email, FILTER_VALIDATE_EMAIL)) {
            $message = 'Enter a valid student ID and email address.';
        } else {
            $statement = $pdo->prepare('UPDATE students SET email = :email WHERE id = :id');
            $statement->execute(['email' => $email, 'id' => $id]);
            $message = $statement->rowCount() > 0 ? 'Email updated.' : 'No matching student was changed.';
        }
    }
}

page_start('Update Student Email');
if ($message !== '') {
    echo '<p>' . h($message) . '</p>';
}
?>
<form method="post">
    <input type="hidden" name="csrf_token" value="<?= h(csrf_token()) ?>">
    <label>Student ID <input type="number" name="id" min="1" required></label>
    <label>New email <input type="email" name="email" maxlength="254" required></label>
    <button type="submit">Update email</button>
</form>
<?php page_end(); ?>
