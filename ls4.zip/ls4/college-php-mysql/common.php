<?php
declare(strict_types=1);

function h(string|int|null $value): string
{
    return htmlspecialchars((string) $value, ENT_QUOTES | ENT_SUBSTITUTE, 'UTF-8');
}

function start_app_session(): void
{
    if (session_status() !== PHP_SESSION_ACTIVE) {
        ini_set('session.use_strict_mode', '1');
        ini_set('session.cookie_httponly', '1');
        ini_set('session.cookie_samesite', 'Lax');
        if (isset($_SERVER['HTTPS']) && $_SERVER['HTTPS'] !== 'off') {
            ini_set('session.cookie_secure', '1');
        }
        session_start();
    }
}

function csrf_token(): string
{
    start_app_session();
    if (empty($_SESSION['csrf_token'])) {
        $_SESSION['csrf_token'] = bin2hex(random_bytes(32));
    }
    return $_SESSION['csrf_token'];
}

function valid_csrf_token(): bool
{
    start_app_session();
    return isset($_POST['csrf_token'], $_SESSION['csrf_token'])
        && hash_equals($_SESSION['csrf_token'], (string) $_POST['csrf_token']);
}

function page_start(string $title): void
{
    start_app_session();
    echo '<!doctype html><html lang="en"><head><meta charset="utf-8">';
    echo '<meta name="viewport" content="width=device-width, initial-scale=1">';
    echo '<title>' . h($title) . '</title><style>';
    echo 'body{font:16px/1.5 system-ui,sans-serif;max-width:900px;margin:2rem auto;padding:0 1rem;color:#18212b;background:#f4f7fb}';
    echo 'h1{color:#123b67}table{width:100%;border-collapse:collapse;background:white}th,td{padding:.7rem;border:1px solid #ccd5df;text-align:left}';
    echo 'th{background:#e8eff7}form{background:white;padding:1rem;margin:1rem 0;border:1px solid #ccd5df;border-radius:8px}';
    echo 'label{display:block;margin:.6rem 0}input,button,select{font:inherit;padding:.45rem}button{cursor:pointer}';
    echo '.ok{color:#126638}.error{color:#a32121}.muted{color:#536273}</style></head><body>';
    echo '<h1>' . h($title) . '</h1>';
}

function page_end(): void
{
    echo '</body></html>';
}
