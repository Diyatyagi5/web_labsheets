-- The requested restricted account omits DELETE. Run this only if the delete
-- exercise should work with college_app; it grants DELETE on students only.
GRANT DELETE ON college_db.students TO 'college_app'@'localhost';
