<?php
declare(strict_types=1);
require __DIR__ . '/common.php';
start_app_session();
if ($_SERVER['REQUEST_METHOD'] !== 'POST' || !valid_csrf_token()) {
    http_response_code(405);
    exit('Submit the sign-out form to end the session.');
}
$_SESSION = [];
if (ini_get('session.use_cookies')) {
    $params = session_get_cookie_params();
    setcookie(session_name(), '', [
        'expires' => time() - 42000,
        'path' => $params['path'],
        'domain' => $params['domain'],
        'secure' => (bool) $params['secure'],
        'httponly' => (bool) $params['httponly'],
        'samesite' => 'Lax',
    ]);
}
session_destroy();
header('Location: login.php');
exit;
