<?php
declare(strict_types=1);
require __DIR__ . '/common.php';
$themes = ['light', 'dark', 'blue'];

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    if (!valid_csrf_token()) {
        http_response_code(400);
        exit('Invalid form token. Reload the page and try again.');
    }
    $theme = (string) ($_POST['theme'] ?? 'light');
    if (!in_array($theme, $themes, true)) {
        $theme = 'light';
    }
    $isSecure = isset($_SERVER['HTTPS']) && $_SERVER['HTTPS'] !== 'off';
    setcookie('preferred_theme', $theme, [
        'expires' => time() + (30 * 24 * 60 * 60),
        'path' => '/',
        'secure' => $isSecure,
        'httponly' => true,
        'samesite' => 'Lax',
    ]);
    header('Location: theme_cookie.php');
    exit;
}

$theme = (string) ($_COOKIE['preferred_theme'] ?? 'light');
if (!in_array($theme, $themes, true)) {
    $theme = 'light';
}
$background = ['light' => '#ffffff', 'dark' => '#20242a', 'blue' => '#e6f2ff'][$theme];
$foreground = $theme === 'dark' ? '#f5f5f5' : '#18212b';
page_start('Theme Cookie Demo');
echo '<main style="background:' . h($background) . ';color:' . h($foreground) . ';padding:1rem;border-radius:8px">';
echo '<p>Theme read from the preference cookie: <strong>' . h($theme) . '</strong></p>';
?>
<form method="post">
    <input type="hidden" name="csrf_token" value="<?= h(csrf_token()) ?>">
    <label>Theme
        <select name="theme">
            <?php foreach ($themes as $option): ?>
                <option value="<?= h($option) ?>" <?= $theme === $option ? 'selected' : '' ?>><?= h(ucfirst($option)) ?></option>
            <?php endforeach; ?>
        </select>
    </label>
    <button type="submit">Save preference</button>
</form>
<?php
echo '</main>';
page_end();
