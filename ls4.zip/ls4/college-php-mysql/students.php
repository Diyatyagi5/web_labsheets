<?php
declare(strict_types=1);
require __DIR__ . '/common.php';
$pdo = require __DIR__ . '/db.php';
$students = $pdo->query('SELECT id, name, email, enrollment_date FROM students ORDER BY id')->fetchAll();
page_start('Students');
?>
<?php if ($students === []): ?>
    <p>No student records yet.</p>
<?php else: ?>
    <table>
        <thead><tr><th>ID</th><th>Name</th><th>Email</th><th>Enrollment date</th></tr></thead>
        <tbody>
        <?php foreach ($students as $student): ?>
            <tr>
                <td><?= h($student['id']) ?></td>
                <td><?= h($student['name']) ?></td>
                <td><?= h($student['email']) ?></td>
                <td><?= h($student['enrollment_date']) ?></td>
            </tr>
        <?php endforeach; ?>
        </tbody>
    </table>
<?php endif; ?>
<?php page_end(); ?>
