<?php
declare(strict_types=1);
require __DIR__ . '/common.php';
start_app_session();
$_SESSION['page_visits'] = ($_SESSION['page_visits'] ?? 0) + 1;
page_start('PHP Session Demo');
?>
<p>This browser session has opened this page <?= h($_SESSION['page_visits']) ?> time(s).</p>
<p>Login state is also kept in this session and read by dashboard.php.</p>
<?php page_end(); ?>
