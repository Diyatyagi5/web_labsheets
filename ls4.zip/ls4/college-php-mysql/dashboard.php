<?php
declare(strict_types=1);
require __DIR__ . '/common.php';
start_app_session();
if (empty($_SESSION['user_id'])) {
    header('Location: login.php');
    exit;
}
page_start('Signed-In Session');
?>
<p class="ok">You are signed in as <?= h($_SESSION['username'] ?? 'user') ?>.</p>
<p>This page reads the login state stored in the PHP session.</p>
<form method="post" action="logout.php">
    <input type="hidden" name="csrf_token" value="<?= h(csrf_token()) ?>">
    <button type="submit">Sign out</button>
</form>
<?php page_end(); ?>
