#!/usr/bin/env python

import cgi
import html

from db import get_connection
from input_validation import validate_user


def respond(status, message):
    print(f"Status: {status}")
    print("Content-Type: text/html; charset=utf-8")
    print()
    print("<!doctype html><html><body>")
    print(f"<p>{html.escape(message)}</p>")
    print("</body></html>")


def main():
    form = cgi.FieldStorage()
    try:
        name, email = validate_user(
            form.getfirst("name", ""), form.getfirst("email", "")
        )
        connection = get_connection()
        try:
            cursor = connection.cursor()
            try:
                cursor.execute(
                    "INSERT INTO users (name, email) VALUES (%s, %s)",
                    (name, email),
                )
                connection.commit()
            except Exception:
                connection.rollback()
                raise
            finally:
                cursor.close()
        finally:
            connection.close()
    except ValueError as error:
        respond("400 Bad Request", str(error))
        return
    except Exception:
        respond("500 Internal Server Error", "The user could not be saved.")
        raise

    respond("201 Created", "User added successfully.")


if __name__ == "__main__":
    main()
