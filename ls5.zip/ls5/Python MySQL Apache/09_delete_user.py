import mysql.connector

from database_logging import get_database_logger
from db import get_connection


logger = get_database_logger()


def delete_user(user_id):
    if not isinstance(user_id, int) or user_id <= 0:
        raise ValueError("User ID must be a positive integer.")

    connection = None
    try:
        connection = get_connection()
        cursor = connection.cursor()
        try:
            cursor.execute("DELETE FROM users WHERE id = %s", (user_id,))
            connection.commit()
            return cursor.rowcount
        finally:
            cursor.close()
    except mysql.connector.Error:
        if connection is not None and connection.is_connected():
            connection.rollback()
        logger.exception("Database error while deleting user id=%s", user_id)
        raise
    finally:
        if connection is not None and connection.is_connected():
            connection.close()


if __name__ == "__main__":
    print(f"Deleted {delete_user(1)} user record(s).")
