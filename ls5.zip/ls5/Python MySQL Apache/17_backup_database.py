import os
import subprocess
from pathlib import Path

from db import connection_config


def backup_database(output_path):
    database = os.environ.get("MYSQL_DATABASE", "python_web_db")
    if not database.replace("_", "").isalnum():
        raise ValueError("MYSQL_DATABASE contains unsupported characters.")

    config = connection_config(database=database)
    command = [
        "mysqldump",
        "--host", config["host"],
        "--port", str(config["port"]),
        "--user", config["user"],
        "--result-file", str(Path(output_path).resolve()),
        "--databases", database,
        "--single-transaction",
    ]
    process_env = os.environ.copy()
    process_env["MYSQL_PWD"] = config["password"]
    subprocess.run(command, env=process_env, check=True)


if __name__ == "__main__":
    destination = os.environ.get(
        "MYSQL_BACKUP_FILE", "python_web_db_backup.sql"
    )
    backup_database(destination)
    print("Database backup written to", destination)
