import mysql.connector

from db import connection_config


DATABASE_NAME = "python_web_db"


def main():
    connection = mysql.connector.connect(**connection_config())
    try:
        cursor = connection.cursor()
        try:
            cursor.execute(f"CREATE DATABASE IF NOT EXISTS `{DATABASE_NAME}`")
            cursor.execute(f"USE `{DATABASE_NAME}`")
            cursor.execute(
                """
                CREATE TABLE IF NOT EXISTS users (
                    id INT AUTO_INCREMENT PRIMARY KEY,
                    name VARCHAR(100) NOT NULL,
                    email VARCHAR(255) NOT NULL UNIQUE
                )
                """
            )
            cursor.execute(
                """
                CREATE TABLE IF NOT EXISTS sessions (
                    session_hash CHAR(64) PRIMARY KEY,
                    visit_count INT NOT NULL DEFAULT 0,
                    expires_at DATETIME NOT NULL,
                    INDEX idx_sessions_expires_at (expires_at)
                )
                """
            )
            connection.commit()
            print("Created database python_web_db and its users/sessions tables.")
        finally:
            cursor.close()
    finally:
        connection.close()


if __name__ == "__main__":
    main()
