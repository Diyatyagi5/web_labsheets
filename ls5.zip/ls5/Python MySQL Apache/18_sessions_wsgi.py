import hashlib
import logging
import secrets
from datetime import datetime, timedelta, timezone
from http.cookies import SimpleCookie

from db import get_connection


logger = logging.getLogger("python_mysql_lab.sessions")
COOKIE_NAME = "python_web_session"
SESSION_LIFETIME_HOURS = 8


def application(environ, start_response):
    request_cookie = SimpleCookie()
    request_cookie.load(environ.get("HTTP_COOKIE", ""))
    cookie = request_cookie.get(COOKIE_NAME)
    token = cookie.value if cookie is not None else ""

    connection = None
    try:
        connection = get_connection()
        cursor = connection.cursor()
        try:
            if token:
                session_hash = hashlib.sha256(token.encode("utf-8")).hexdigest()
                cursor.execute(
                    """
                    UPDATE sessions
                    SET visit_count = visit_count + 1
                    WHERE session_hash = %s AND expires_at > UTC_TIMESTAMP()
                    """,
                    (session_hash,),
                )
                if cursor.rowcount == 0:
                    token = ""

            if not token:
                token = secrets.token_urlsafe(32)
                session_hash = hashlib.sha256(token.encode("utf-8")).hexdigest()
                expires_at = datetime.now(timezone.utc) + timedelta(
                    hours=SESSION_LIFETIME_HOURS
                )
                cursor.execute(
                    """
                    INSERT INTO sessions (session_hash, visit_count, expires_at)
                    VALUES (%s, 1, %s)
                    """,
                    (session_hash, expires_at.replace(tzinfo=None)),
                )
            connection.commit()
            cursor.execute(
                "SELECT visit_count FROM sessions WHERE session_hash = %s",
                (session_hash,),
            )
            visits = cursor.fetchone()[0]
        finally:
            cursor.close()
    except Exception:
        if connection is not None:
            connection.rollback()
        logger.exception("Unable to read or update the MySQL session")
        body = b'{"error":"Session storage unavailable"}'
        start_response(
            "500 Internal Server Error",
            [("Content-Type", "application/json; charset=utf-8"),
             ("Content-Length", str(len(body)))],
        )
        return [body]
    finally:
        if connection is not None:
            connection.close()

    body = ('{"visits":' + str(visits) + "}").encode("utf-8")
    response_cookie = (
        f"{COOKIE_NAME}={token}; Path=/; Max-Age={SESSION_LIFETIME_HOURS * 3600}; "
        "HttpOnly; SameSite=Lax"
    )
    if environ.get("wsgi.url_scheme") == "https":
        response_cookie += "; Secure"
    start_response(
        "200 OK",
        [("Content-Type", "application/json; charset=utf-8"),
         ("Content-Length", str(len(body))),
         ("Set-Cookie", response_cookie)],
    )
    return [body]
