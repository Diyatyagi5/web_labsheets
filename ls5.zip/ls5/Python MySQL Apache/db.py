import os

import mysql.connector


def connection_config(database=None):
    user = os.environ.get("MYSQL_USER")
    if not user:
        raise RuntimeError("Set MYSQL_USER in the environment before connecting.")

    config = {
        "host": os.environ.get("MYSQL_HOST", "127.0.0.1"),
        "port": int(os.environ.get("MYSQL_PORT", "3306")),
        "user": user,
        "password": os.environ.get("MYSQL_PASSWORD", ""),
    }
    if database is not None:
        config["database"] = database
    return config


def get_connection(database=None):
    selected_database = database or os.environ.get(
        "MYSQL_DATABASE", "python_web_db"
    )
    return mysql.connector.connect(
        **connection_config(database=selected_database)
    )
