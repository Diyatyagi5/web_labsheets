import os

from sqlalchemy import String, create_engine
from sqlalchemy.engine import URL
from sqlalchemy.orm import DeclarativeBase, Mapped, mapped_column, sessionmaker


class Base(DeclarativeBase):
    pass


class User(Base):
    __tablename__ = "users"

    id: Mapped[int] = mapped_column(primary_key=True, autoincrement=True)
    name: Mapped[str] = mapped_column(String(100), nullable=False)
    email: Mapped[str] = mapped_column(String(255), unique=True, nullable=False)


def create_session_factory():
    user = os.environ.get("MYSQL_USER")
    if not user:
        raise RuntimeError("Set MYSQL_USER in the environment before connecting.")

    url = URL.create(
        "mysql+mysqlconnector",
        username=user,
        password=os.environ.get("MYSQL_PASSWORD", ""),
        host=os.environ.get("MYSQL_HOST", "127.0.0.1"),
        port=int(os.environ.get("MYSQL_PORT", "3306")),
        database=os.environ.get("MYSQL_DATABASE", "python_web_db"),
    )
    engine = create_engine(url, pool_pre_ping=True)
    Base.metadata.create_all(engine)
    return sessionmaker(bind=engine)


if __name__ == "__main__":
    Session = create_session_factory()
    with Session.begin() as session:
        session.add(User(name="ORM Example", email="orm@example.com"))
    print("Created ORM example user.")
