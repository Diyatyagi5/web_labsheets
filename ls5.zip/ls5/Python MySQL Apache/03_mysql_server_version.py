from db import connection_config
import mysql.connector


def main():
    connection = mysql.connector.connect(**connection_config())
    try:
        cursor = connection.cursor()
        try:
            cursor.execute("SELECT VERSION()")
            row = cursor.fetchone()
            print("MySQL server version:", row[0])
        finally:
            cursor.close()
    finally:
        connection.close()


if __name__ == "__main__":
    main()
