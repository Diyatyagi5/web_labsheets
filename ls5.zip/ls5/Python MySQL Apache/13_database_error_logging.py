import mysql.connector

from database_logging import get_database_logger
from db import get_connection


logger = get_database_logger()


def get_user_count():
    try:
        connection = get_connection()
        try:
            cursor = connection.cursor()
            try:
                cursor.execute("SELECT COUNT(*) FROM users")
                return cursor.fetchone()[0]
            finally:
                cursor.close()
        finally:
            connection.close()
    except mysql.connector.Error:
        logger.exception("Database query failed while counting users")
        raise


if __name__ == "__main__":
    print("User count:", get_user_count())
