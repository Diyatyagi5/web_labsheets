import re


EMAIL_PATTERN = re.compile(r"^[^@\s]+@[^@\s]+\.[^@\s]+$")


def validate_user(name, email):
    clean_name = name.strip()
    clean_email = email.strip().lower()

    if not clean_name or len(clean_name) > 100:
        raise ValueError("Name must contain between 1 and 100 characters.")
    if len(clean_email) > 255 or not EMAIL_PATTERN.fullmatch(clean_email):
        raise ValueError("Enter a valid email address of at most 255 characters.")

    return clean_name, clean_email
