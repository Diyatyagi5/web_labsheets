from db import get_connection
from input_validation import validate_user


def add_user(name, email):
    clean_name, clean_email = validate_user(name, email)
    connection = get_connection()
    try:
        cursor = connection.cursor()
        try:
            cursor.execute(
                "INSERT INTO users (name, email) VALUES (%s, %s)",
                (clean_name, clean_email),
            )
            connection.commit()
            return cursor.lastrowid
        except Exception:
            connection.rollback()
            raise
        finally:
            cursor.close()
    finally:
        connection.close()


if __name__ == "__main__":
    print("Created user with id", add_user("Nora Lee", "nora@example.com"))
