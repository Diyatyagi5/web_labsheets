from db import get_connection


def find_users(name_fragment):
    if not isinstance(name_fragment, str) or not name_fragment.strip():
        raise ValueError("Enter a non-empty name filter.")

    connection = get_connection()
    try:
        cursor = connection.cursor()
        try:
            cursor.execute(
                "SELECT id, name, email FROM users WHERE name LIKE %s ORDER BY id",
                (f"%{name_fragment.strip()}%",),
            )
            return cursor.fetchall()
        finally:
            cursor.close()
    finally:
        connection.close()


if __name__ == "__main__":
    for user in find_users("Asha"):
        print(user)
