import os

from mysql.connector.pooling import MySQLConnectionPool

from db import connection_config


pool = MySQLConnectionPool(
    pool_name="python_web_pool",
    pool_size=max(1, min(int(os.environ.get("MYSQL_POOL_SIZE", "5")), 32)),
    **connection_config(
        database=os.environ.get("MYSQL_DATABASE", "python_web_db")
    ),
)


def get_pooled_connection():
    return pool.get_connection()


def main():
    connection = get_pooled_connection()
    try:
        cursor = connection.cursor()
        try:
            cursor.execute("SELECT COUNT(*) FROM users")
            print("User count:", cursor.fetchone()[0])
        finally:
            cursor.close()
    finally:
        connection.close()


if __name__ == "__main__":
    main()
