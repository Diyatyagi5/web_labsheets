import html

from db import get_connection


def build_users_html(rows):
    table_rows = "".join(
        "<tr>"
        f"<td>{int(user_id)}</td>"
        f"<td>{html.escape(name)}</td>"
        f"<td>{html.escape(email)}</td>"
        "</tr>"
        for user_id, name, email in rows
    )
    return (
        "<!doctype html><html><head><meta charset=\"utf-8\">"
        "<title>Users</title></head><body><h1>Users</h1>"
        "<table><thead><tr><th>ID</th><th>Name</th><th>Email</th></tr></thead>"
        f"<tbody>{table_rows}</tbody></table></body></html>"
    )


def main():
    connection = get_connection()
    try:
        cursor = connection.cursor()
        try:
            cursor.execute("SELECT id, name, email FROM users ORDER BY id")
            response_body = build_users_html(cursor.fetchall())
            print("Content-Type: text/html; charset=utf-8")
            print()
            print(response_body)
        finally:
            cursor.close()
    finally:
        connection.close()


if __name__ == "__main__":
    main()
