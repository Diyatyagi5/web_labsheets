from db import get_connection
from input_validation import validate_user


def update_user(user_id, name, email):
    if not isinstance(user_id, int) or user_id <= 0:
        raise ValueError("User ID must be a positive integer.")
    clean_name, clean_email = validate_user(name, email)

    connection = get_connection()
    try:
        cursor = connection.cursor()
        try:
            cursor.execute(
                "UPDATE users SET name = %s, email = %s WHERE id = %s",
                (clean_name, clean_email, user_id),
            )
            connection.commit()
            return cursor.rowcount
        except Exception:
            connection.rollback()
            raise
        finally:
            cursor.close()
    finally:
        connection.close()


if __name__ == "__main__":
    changed = update_user(1, "Asha Patel", "asha.patel@example.com")
    print(f"Updated {changed} user record(s).")
