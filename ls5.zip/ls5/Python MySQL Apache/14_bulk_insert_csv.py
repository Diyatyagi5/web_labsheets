import csv
import sys

from db import get_connection
from input_validation import validate_user


def import_users(csv_path):
    with open(csv_path, newline="", encoding="utf-8-sig") as csv_file:
        reader = csv.DictReader(csv_file)
        if not reader.fieldnames or not {"name", "email"}.issubset(reader.fieldnames):
            raise ValueError("CSV file must contain name and email headers.")
        rows = [
            validate_user(row["name"], row["email"])
            for row in reader
        ]

    if not rows:
        return 0

    connection = get_connection()
    try:
        cursor = connection.cursor()
        try:
            cursor.executemany(
                "INSERT INTO users (name, email) VALUES (%s, %s)", rows
            )
            connection.commit()
            return cursor.rowcount
        except Exception:
            connection.rollback()
            raise
        finally:
            cursor.close()
    finally:
        connection.close()


if __name__ == "__main__":
    if len(sys.argv) != 2:
        raise SystemExit("Usage: python 13_bulk_insert_csv.py users.csv")
    print(f"Inserted {import_users(sys.argv[1])} record(s).")
