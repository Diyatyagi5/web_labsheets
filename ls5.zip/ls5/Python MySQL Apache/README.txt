Python, MySQL, and Apache lab exercises
=======================================

Files 01 through 21 are separate examples for the corresponding lab tasks.
The shared db.py reads MYSQL_HOST, MYSQL_PORT, MYSQL_USER, MYSQL_PASSWORD,
and MYSQL_DATABASE from the process environment. Set MYSQL_DATABASE to
python_web_db after running 04_create_database.py. No credentials are stored
in these files.

Local setup (PowerShell)
------------------------
    py -m venv .venv
    .\.venv\Scripts\Activate.ps1
    python -m pip install -r requirements.txt
    $env:MYSQL_HOST = "127.0.0.1"
    $env:MYSQL_PORT = "3306"
    $env:MYSQL_USER = "your_mysql_user"
    $env:MYSQL_PASSWORD = "your_mysql_password"

Run scripts from this directory. To install or refresh the dependencies later,
run `python 02_install_dependencies.py`. First run 04_create_database.py, then 05
or another exercise that uses python_web_db. The CGI examples use Python's
deprecated cgi module and require Python 3.12 or earlier. CGI is not supported
by Python 3.13+; use the WSGI examples for newer Python versions.

Apache CGI
----------
Review apache-cgi.conf and .htaccess.example, substitute the absolute paths
for this directory and the Python executable, and merge the directives into
the Apache configuration. Enable mod_cgi (or mod_cgid where appropriate),
ScriptAlias the CGI directory, and permit Options/handler overrides if using
.htaccess. CGI files need a valid Python shebang and execute permission on
Unix-like hosts. On Windows, configure the handler with the actual Python.exe
path as shown in the Apache configuration.

Apache WSGI and virtual environments
------------------------------------
apache-wsgi.conf shows mod_wsgi daemon configuration and an application
mount. Install a mod_wsgi build compatible with the exact Python used by the
virtual environment; set the paths to that environment and this directory.
Apache configuration syntax and module paths vary by installation. Restart
Apache after configuration changes. 01_apache_hello.py can be run directly
to verify its output; it can also be exposed as a CGI endpoint using the CGI
configuration. The WSGI examples are 16_json_endpoint_wsgi.py and
18_sessions_wsgi.py.

Database notes
--------------
The MySQL server must be running and the account must be allowed to create
python_web_db for exercise 04. The CSV example expects a CSV header with
name,email columns. The backup example requires mysqldump on PATH.
