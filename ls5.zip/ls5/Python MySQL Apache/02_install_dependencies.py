import subprocess
import sys
from pathlib import Path


def install_dependencies():
    requirements_file = Path(__file__).with_name("requirements.txt")
    subprocess.run(
        [sys.executable, "-m", "pip", "install", "-r", str(requirements_file)],
        check=True,
    )


if __name__ == "__main__":
    install_dependencies()
    print("MySQL connector and SQLAlchemy dependencies are installed.")
