from db import get_connection


def get_user_summary():
    connection = get_connection()
    try:
        cursor = connection.cursor(dictionary=True)
        try:
            cursor.execute(
                """
                SELECT
                    COUNT(*) AS user_count,
                    COALESCE(AVG(CHAR_LENGTH(name)), 0) AS average_name_length
                FROM users
                """
            )
            return cursor.fetchone()
        finally:
            cursor.close()
    finally:
        connection.close()


if __name__ == "__main__":
    summary = get_user_summary()
    print(f"Total users: {summary['user_count']}")
    print(f"Average name length: {summary['average_name_length']:.2f}")
