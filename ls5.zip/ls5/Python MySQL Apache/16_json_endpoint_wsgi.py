import json
import logging

from db import get_connection


logger = logging.getLogger("python_mysql_lab.wsgi")


def application(environ, start_response):
    if environ.get("PATH_INFO") != "/users":
        body = json.dumps({"error": "Not found"}).encode("utf-8")
        start_response(
            "404 Not Found",
            [("Content-Type", "application/json; charset=utf-8"),
             ("Content-Length", str(len(body)))],
        )
        return [body]

    connection = None
    try:
        connection = get_connection()
        cursor = connection.cursor(dictionary=True)
        try:
            cursor.execute("SELECT id, name, email FROM users ORDER BY id")
            payload = {"users": cursor.fetchall()}
        finally:
            cursor.close()
        body = json.dumps(payload).encode("utf-8")
        status = "200 OK"
    except Exception:
        logger.exception("Unable to generate the users JSON response")
        body = json.dumps({"error": "Database request failed"}).encode("utf-8")
        status = "500 Internal Server Error"
    finally:
        if connection is not None:
            connection.close()

    start_response(
        status,
        [("Content-Type", "application/json; charset=utf-8"),
         ("Content-Length", str(len(body)))],
    )
    return [body]
