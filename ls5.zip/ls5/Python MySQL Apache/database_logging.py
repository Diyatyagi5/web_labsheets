import logging
import os
from logging.handlers import RotatingFileHandler
from pathlib import Path


def get_database_logger():
    log_path = Path(
        os.environ.get("MYSQL_ERROR_LOG", str(Path(__file__).parent / "logs" / "mysql.log"))
    )
    log_path.parent.mkdir(parents=True, exist_ok=True)

    logger = logging.getLogger("python_mysql_lab")
    if not logger.handlers:
        handler = RotatingFileHandler(
            log_path, maxBytes=1_000_000, backupCount=3, encoding="utf-8"
        )
        handler.setFormatter(
            logging.Formatter("%(asctime)s %(levelname)s %(message)s")
        )
        logger.addHandler(handler)
        logger.setLevel(logging.INFO)
    return logger
