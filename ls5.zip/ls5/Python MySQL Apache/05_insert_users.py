from db import get_connection
from input_validation import validate_user


USERS = [
    ("Asha Patel", "asha@example.com"),
    ("Ravi Kumar", "ravi@example.com"),
    ("Mina Shah", "mina@example.com"),
]


def main():
    validated_users = [validate_user(name, email) for name, email in USERS]
    connection = get_connection()
    try:
        cursor = connection.cursor()
        try:
            cursor.executemany(
                "INSERT INTO users (name, email) VALUES (%s, %s)",
                validated_users,
            )
            connection.commit()
            print(f"Inserted {cursor.rowcount} user record(s).")
        except Exception:
            connection.rollback()
            raise
        finally:
            cursor.close()
    finally:
        connection.close()


if __name__ == "__main__":
    main()
