document.addEventListener("DOMContentLoaded", () => {
  const menuToggle = document.querySelector(".menu-toggle");
  const navLinks = document.querySelector(".nav-links");
  menuToggle?.addEventListener("click", () => {
    const open = navLinks.classList.toggle("open");
    menuToggle.setAttribute("aria-expanded", String(open));
    menuToggle.setAttribute("aria-label", open ? "Close navigation" : "Open navigation");
  });

  const themeToggle = document.querySelector(".theme-toggle");
  const savedTheme = localStorage.getItem("portfolio-theme");
  if (savedTheme === "dark") document.body.classList.add("dark-mode");
  themeToggle?.addEventListener("click", () => {
    const dark = document.body.classList.toggle("dark-mode");
    localStorage.setItem("portfolio-theme", dark ? "dark" : "light");
    themeToggle.setAttribute("aria-label", dark ? "Switch to light mode" : "Switch to dark mode");
  });

  document.querySelectorAll('a[href^="#"]').forEach((anchor) => {
    anchor.addEventListener("click", (event) => {
      const target = document.querySelector(anchor.getAttribute("href"));
      if (target) { event.preventDefault(); target.scrollIntoView({ behavior: "smooth" }); }
    });
  });

  const topButton = document.querySelector("#back-to-top");
  window.addEventListener("scroll", () => topButton?.classList.toggle("visible", window.scrollY > 500));
  topButton?.addEventListener("click", () => window.scrollTo({ top: 0, behavior: "smooth" }));

  const counters = document.querySelectorAll(".counter");
  const counterObserver = new IntersectionObserver((entries, observer) => {
    entries.forEach((entry) => {
      if (!entry.isIntersecting) return;
      const element = entry.target;
      const target = Number(element.dataset.target);
      let current = 0;
      const step = Math.max(1, Math.ceil(target / 45));
      const timer = setInterval(() => {
        current = Math.min(target, current + step);
        element.textContent = current;
        if (current === target) clearInterval(timer);
      }, 30);
      observer.unobserve(element);
    });
  }, { threshold: .6 });
  counters.forEach((counter) => counterObserver.observe(counter));

  const testimonials = [
    ["“Alex has the rare ability to make the complicated feel simple. The new product launched ahead of schedule and exceeded every target.”", "— Maya Chen, Founder at Solace"],
    ["“The best creative partner we’ve worked with. Alex brought clarity to our story and made the whole process genuinely enjoyable.”", "— Theo James, Director at Good Kind"],
    ["“Thoughtful, sharp and endlessly reliable. The new identity feels like us, only braver.”", "— Priya Shah, Co-founder at Field Notes"]
  ];
  let testimonialIndex = 0;
  const quote = document.querySelector("#testimonial-quote");
  const author = document.querySelector("#testimonial-author");
  const updateTestimonial = (change) => {
    if (!quote || !author) return;
    testimonialIndex = (testimonialIndex + change + testimonials.length) % testimonials.length;
    quote.style.opacity = "0";
    setTimeout(() => { quote.textContent = testimonials[testimonialIndex][0]; author.textContent = testimonials[testimonialIndex][1]; quote.style.opacity = "1"; }, 180);
  };
  document.querySelector("#testimonial-prev")?.addEventListener("click", () => updateTestimonial(-1));
  document.querySelector("#testimonial-next")?.addEventListener("click", () => updateTestimonial(1));

  document.querySelectorAll(".faq-item button").forEach((button) => button.addEventListener("click", () => {
    const item = button.closest(".faq-item");
    const open = item.classList.toggle("open");
    button.setAttribute("aria-expanded", String(open));
  }));

  const search = document.querySelector("#project-search");
  const emptyState = document.querySelector("#empty-state");
  search?.addEventListener("input", () => {
    const term = search.value.toLowerCase().trim();
    let visible = 0;
    document.querySelectorAll("[data-project]").forEach((card) => {
      const matches = card.dataset.project.includes(term);
      card.hidden = !matches;
      if (matches) visible++;
    });
    if (emptyState) emptyState.hidden = visible !== 0;
  });

  const form = document.querySelector("#contact-form");
  form?.addEventListener("submit", (event) => {
    event.preventDefault();
    const fields = [
      ["name", (value) => value.length > 1, "Please enter your name."],
      ["email", (value) => /^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(value), "Please enter a valid email."],
      ["message", (value) => value.length > 10, "Please write a little more about your project."]
    ];
    let valid = true;
    fields.forEach(([id, test, message]) => {
      const input = document.querySelector(`#${id}`);
      const error = document.querySelector(`#${id}-error`);
      const passes = test(input.value.trim());
      error.textContent = passes ? "" : message;
      input.setAttribute("aria-invalid", String(!passes));
      valid = valid && passes;
    });
    const status = document.querySelector("#form-status");
    if (valid) { status.textContent = "Thanks! Your message is ready to send."; form.reset(); }
    else status.textContent = "";
  });

  const modal = document.querySelector("#pricing-modal");
  const closeModal = () => { modal?.classList.remove("open"); modal?.setAttribute("aria-hidden", "true"); };
  document.querySelectorAll(".modal-trigger").forEach((button) => button.addEventListener("click", () => { modal.classList.add("open"); modal.setAttribute("aria-hidden", "false"); }));
  modal?.querySelector(".modal-close")?.addEventListener("click", closeModal);
  modal?.addEventListener("click", (event) => { if (event.target === modal) closeModal(); });
  document.addEventListener("keydown", (event) => { if (event.key === "Escape") closeModal(); });
});
