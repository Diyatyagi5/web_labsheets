# Moss & Crumb presentation outline

## Slide 1 — The brief
Introduce the cafe, audience, goals, and success measure: more visits and table bookings.

## Slide 2 — Brand direction
Show the forest, sage, cream, and terracotta palette; explain the serif/sans-serif type pairing and warm editorial tone.

## Slide 3 — Wireframe
Present the home and visit-us ASCII wireframes from `project-specification.md`.

## Slide 4 — Development
Explain semantic HTML, reusable CSS tokens, mobile-first Grid/Flexbox, and the shared JavaScript module.

## Slide 5 — Interactions
Demonstrate the responsive menu, hero carousel, contrast toggle, booking validation, and social/share footer.

## Slide 6 — Responsive and accessibility testing
Show 320px, 768px, and desktop screenshots; demonstrate keyboard navigation, skip link, form errors, labels, and map title.

## Slide 7 — Performance and SEO
Explain compressed responsive image delivery, deferred JavaScript, metadata, Open Graph tags, print styles, and Lighthouse targets.

## Slide 8 — Live demo
Run the local server, visit the home page, change carousel slides, submit an invalid and valid booking, resize the viewport, and open the map.
