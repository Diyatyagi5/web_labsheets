document.addEventListener("DOMContentLoaded", () => {
  const menuButton = document.querySelector(".menu-button");
  const navLinks = document.querySelector(".nav-links");
  menuButton?.addEventListener("click", () => {
    const open = navLinks.classList.toggle("open");
    menuButton.setAttribute("aria-expanded", String(open));
  });

  const contrastButton = document.querySelector(".contrast-button");
  contrastButton?.addEventListener("click", () => document.body.classList.toggle("high-contrast"));

  const slides = [
    { image: "https://images.unsplash.com/photo-1554118811-1e0d58224f24?w=1800&q=75", label: "Neighbourhood cafe" },
    { image: "https://images.unsplash.com/photo-1498837167922-ddd27525d352?w=1800&q=75", label: "Seasonal kitchen" },
    { image: "https://images.unsplash.com/photo-1495474472287-4d71bcdd2085?w=1800&q=75", label: "Small-batch coffee" }
  ];
  const hero = document.querySelector(".hero");
  const slideNumber = document.querySelector("#slide-number");
  let slideIndex = 0;
  const showSlide = (change) => {
    if (!hero) return;
    slideIndex = (slideIndex + change + slides.length) % slides.length;
    hero.style.backgroundImage = `linear-gradient(90deg, rgba(24,49,36,.94), rgba(24,49,36,.25)), url("${slides[slideIndex].image}")`;
    slideNumber.textContent = String(slideIndex + 1).padStart(2, "0");
  };
  document.querySelector(".carousel-prev")?.addEventListener("click", () => showSlide(-1));
  document.querySelector(".carousel-next")?.addEventListener("click", () => showSlide(1));

  const form = document.querySelector("#booking");
  form?.addEventListener("submit", (event) => {
    event.preventDefault();
    const checks = [
      ["guest-name", value => value.length > 1, "Please enter your name."],
      ["guest-email", value => /^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(value), "Please enter a valid email."],
      ["date", value => value !== "", "Please choose a date."]
    ];
    let valid = true;
    checks.forEach(([id, test, message]) => {
      const input = document.querySelector(`#${id}`);
      const error = document.querySelector(`#${id}-error`);
      const passed = test(input.value.trim());
      if (error) error.textContent = passed ? "" : message;
      input.setAttribute("aria-invalid", String(!passed));
      valid = valid && passed;
    });
    const status = document.querySelector("#booking-status");
    status.textContent = valid ? "Thanks! Your booking request has been received." : "";
    if (valid) form.reset();
  });
});
