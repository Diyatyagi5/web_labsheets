Moss & Crumb local demo

Run from this directory:
  py -m http.server 8000

Then open http://localhost:8000/ in a browser.

Files:
  index.html       Home, carousel, offerings, testimonials
  menu.html        Seasonal menu
  contact.html     Map, booking form, hours
  styles.css       Mobile-first responsive styling and print rules
  script.js        Menu, carousel, contrast theme, and form validation
  project-specification.md
  design-rationale.md
  presentation.md
