# Moss & Crumb project specification

## Client
Moss & Crumb is a fictional eco-friendly neighbourhood cafe in Bristol. The target audience is local residents, remote workers, weekend visitors, and customers who value seasonal food and lower-impact choices.

## Goals
- Make the cafe feel warm, calm, local, and trustworthy.
- Present food, coffee, opening hours, location, and booking information clearly.
- Encourage table bookings and in-person visits.
- Meet mobile-first accessibility and performance expectations.

## Pages and content
- **Home:** hero carousel, introduction, offerings, testimonials, footer.
- **Menu:** seasonal menu categories and dietary note.
- **Visit us:** embedded map, booking form, opening hours, contact details.

## Functional requirements
Mobile navigation, hero carousel, theme contrast toggle, client-side booking validation, responsive Google Maps embed, social/share links, keyboard-friendly controls, SEO metadata, and print styles.

## Wireframe layout
```text
HOME
┌──────────────────────────────┐
│ Logo       Home Menu Visit us│ Header / navigation
├──────────────────────────────┤
│                              │
│     Hero image + CTA         │ Carousel controls
│                              │
├──────────────┬───────────────┤
│ Intro copy   │ Intro copy     │
├──────────────┴───────────────┤
│ Offering 1 │ Offering 2 │ 3   │
├──────────────────────────────┤
│ Testimonial 1 │ 2 │ 3         │
├──────────────────────────────┤
│ Footer / socials / hours      │
└──────────────────────────────┘

VISIT US
┌──────────────────────────────┐
│ Page title                    │
├───────────────┬──────────────┤
│ Map + address │ Booking form │
├───────────────┴──────────────┤
│ Opening hours                │
└──────────────────────────────┘
```
