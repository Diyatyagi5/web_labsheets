# Design rationale and audit notes

## Visual direction
The palette pairs deep forest green with sage surfaces, warm cream space, and a terracotta accent. Green communicates nature and trust; cream keeps the interface calm; terracotta adds appetite and action emphasis. Text uses a readable system sans-serif for body copy and a soft serif for editorial headings.

The layout uses generous whitespace, short content blocks, clear section labels, and repeated card patterns. The visual language is intentionally tactile and local rather than overly polished or corporate.

## Accessibility
- Semantic `header`, `nav`, `main`, `section`, `article`, and `footer` landmarks are used.
- A skip link is available on every page.
- Interactive controls expose labels or `aria-label`/`aria-expanded` states.
- The map iframe has a descriptive title.
- Decorative remote photography is presented as CSS backgrounds; all content images would receive alt text if converted to `<img>` assets.
- Form errors are explicit, and status messages use `role="status"`.
- Keyboard focus remains native and controls are large enough for touch.
- Print styles remove navigation and preserve readable content.

## Performance and testing plan
Hero and card photography use remote Unsplash query parameters for a smaller 700–1800px delivery. The production checklist is to download WebP/AVIF derivatives, run them through an image compressor, minify `styles.css` and `script.js`, and add cache headers.

The local pages are designed for Chrome, Firefox, Edge, and Safari standards: CSS Grid/Flexbox, optional chaining, `classList`, and standard form APIs only. Test at 320px, 375px, 768px, 1024px, and 1440px widths. Run Lighthouse for Performance, Accessibility, Best Practices, and SEO before presentation.

## Final audit checklist
- [x] Semantic landmarks, skip link, focusable controls
- [x] SEO title, description, and Open Graph metadata on each page
- [x] Responsive mobile-first layout
- [x] Carousel, booking validation, contrast toggle, map embed
- [x] Testimonials with accessible rating labels
- [x] Print stylesheet
- [ ] Replace demo social URLs and example email with production values
- [ ] Run Lighthouse against the local server
